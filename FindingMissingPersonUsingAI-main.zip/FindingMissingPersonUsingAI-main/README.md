# FindingMissingPersonUsingAI
### A Final Year Project of B.E. CSE (2019-23)

__Title__ : AI - Assisted  Missing Person Location and Retrieval System

__Description__ : This project is about Finding the Missing person using face_recognition through CCTV and sending the whereabouts information to his/her Family via SMS.
